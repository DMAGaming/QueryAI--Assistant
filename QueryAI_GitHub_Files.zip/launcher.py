import os
import tkinter as tk
from tkinter import messagebox

def launch():
    try:
        os.startfile("dist/queryAI.exe")  # Adjust path if needed
    except Exception as e:
        messagebox.showerror("Error", f"Could not launch: {e}")

root = tk.Tk()
root.title("Launch QueryAI")
root.geometry("300x150")

tk.Label(root, text="Click to launch QueryAI!", font=("Arial", 12)).pack(pady=20)
tk.Button(root, text="Launch", command=launch, font=("Arial", 10)).pack()

root.mainloop()
