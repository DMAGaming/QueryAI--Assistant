All-in-One AI Assistant
------------------------

Features:
- Chatbot with memory and emotion detection
- Wake word activation: “Q open up”
- Voice input and output
- Webcam image recognition (objects)
- Tkinter GUI

Run Instructions:
1. Install Python 3.10+
2. Install requirements:
   pip install -r requirements.txt
3. Run the assistant:
   python your_script.py

Packaged as EXE:
pyinstaller --onefile --windowed --icon=icon.ico your_script.py
