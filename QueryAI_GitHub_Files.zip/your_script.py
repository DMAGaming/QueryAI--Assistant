import tkinter as tk
from tkinter import messagebox, simpledialog
import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input, decode_predictions
from PIL import Image, ImageTk
import speech_recognition as sr
import pyttsx3
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
import threading
import json
import os
from textblob import TextBlob

# ================================
# Initialization
# ================================
chat_tokenizer = AutoTokenizer.from_pretrained("microsoft/DialoGPT-small")
chat_model = AutoModelForCausalLM.from_pretrained("microsoft/DialoGPT-small")
chat_history_ids = None

object_model = MobileNetV2(weights='imagenet')
tts_engine = pyttsx3.init()

memory_file = "chat_memory.json"
if not os.path.exists(memory_file):
    with open(memory_file, "w") as f:
        json.dump({"history": [], "emotions": []}, f)

def load_memory():
    with open(memory_file, "r") as f:
        return json.load(f)

def save_memory(memory):
    with open(memory_file, "w") as f:
        json.dump(memory, f, indent=2)

def speak(text):
    tts_engine.say(text)
    tts_engine.runAndWait()

def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        try:
            audio = recognizer.listen(source, timeout=5)
            return recognizer.recognize_google(audio)
        except Exception:
            return ""

def detect_emotion(text):
    blob = TextBlob(text)
    polarity = blob.sentiment.polarity
    if polarity > 0.3:
        return "happy"
    elif polarity < -0.3:
        return "sad"
    else:
        return "neutral"

def chatbot_response(user_input, memory):
    global chat_history_ids
    new_input_ids = chat_tokenizer.encode(user_input + chat_tokenizer.eos_token, return_tensors='pt')
    bot_input_ids = torch.cat([chat_history_ids, new_input_ids], dim=-1) if chat_history_ids is not None else new_input_ids
    chat_history_ids = chat_model.generate(bot_input_ids, max_length=1000, pad_token_id=chat_tokenizer.eos_token_id)
    response = chat_tokenizer.decode(chat_history_ids[:, bot_input_ids.shape[-1]:][0], skip_special_tokens=True)
    memory['history'].append({"user": user_input, "bot": response})
    save_memory(memory)
    return response

def capture_and_classify():
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    cap.release()
    if ret:
        image = cv2.resize(frame, (224, 224))
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        img_array = np.expand_dims(image, axis=0)
        img_array = preprocess_input(img_array)
        predictions = object_model.predict(img_array)
        label = decode_predictions(predictions, top=1)[0][0][1]
        result_label.config(text=f"I see: {label}")
        speak(f"I see a {label}.")
    else:
        result_label.config(text="Failed to capture image.")

# ================================
# Wake Word Listener
# ================================
def wake_word_listener():
    while True:
        try:
            text = recognize_speech().lower()
            if "q open up" in text:
                speak("I'm here. What can I do for you?")
                break
        except:
            continue

threading.Thread(target=wake_word_listener, daemon=True).start()

# ================================
# GUI Setup
# ================================
app = tk.Tk()
app.title("All-in-One AI Assistant")
app.geometry("500x700")

chat_frame = tk.Frame(app)
chat_frame.pack(pady=10)

chat_log = tk.Text(chat_frame, height=12, width=60)
chat_log.pack()

user_input = tk.Entry(app, width=50)
user_input.pack(pady=5)

memory = load_memory()

# Add memory viewer
def view_memory():
    history = memory.get('history', [])
    emotion_log = memory.get('emotions', [])
    mem_win = tk.Toplevel(app)
    mem_win.title("Memory Viewer")
    mem_text = tk.Text(mem_win, wrap=tk.WORD, width=60, height=25)
    mem_text.pack()
    mem_text.insert(tk.END, "--- Conversation History ---\n")
    for h in history:
        mem_text.insert(tk.END, f"You: {h['user']}\nBot: {h['bot']}\n\n")
    mem_text.insert(tk.END, "--- Emotion Log ---\n")
    for emo in emotion_log:
        mem_text.insert(tk.END, f"{emo['emotion']}: {emo['text']}\n")

def send_chat():
    text = user_input.get()
    user_input.delete(0, tk.END)
    emotion = detect_emotion(text)
    chat_log.insert(tk.END, f"You ({emotion}): {text}\n")
    memory['emotions'].append({"text": text, "emotion": emotion})
    response = chatbot_response(text, memory)
    chat_log.insert(tk.END, f"Bot: {response}\n")
    speak(response)

chat_button = tk.Button(app, text="Send to Chatbot", command=send_chat)
chat_button.pack(pady=5)

def voice_input():
    chat_log.insert(tk.END, "Listening...\n")
    text = recognize_speech()
    if text:
        emotion = detect_emotion(text)
        chat_log.insert(tk.END, f"You (voice, {emotion}): {text}\n")
        memory['emotions'].append({"text": text, "emotion": emotion})
        response = chatbot_response(text, memory)
        chat_log.insert(tk.END, f"Bot: {response}\n")
        speak(response)
    else:
        chat_log.insert(tk.END, "Didn't catch that.\n")

voice_button = tk.Button(app, text="Voice Input", command=lambda: threading.Thread(target=voice_input).start())
voice_button.pack(pady=5)

image_button = tk.Button(app, text="Recognize Image (Object)", command=capture_and_classify)
image_button.pack(pady=10)

result_label = tk.Label(app, text="", font=("Arial", 14))
result_label.pack(pady=10)

view_mem_button = tk.Button(app, text="View Memory", command=view_memory)
view_mem_button.pack(pady=10)

app.mainloop()
